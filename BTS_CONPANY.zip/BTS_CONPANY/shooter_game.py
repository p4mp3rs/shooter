#Створи власний Шутер!
from pygame import *
from random import randint
import time as timer
mixer.init()
mixer.music.load('space.ogg')
mixer.music.play()
kick = mixer.Sound('fire.ogg')

window = display.set_mode((700,500))
display.set_caption('Shooter')

img_back = "galaxy.jpg"  # фон гри
img_hero = "rocket.png"  # герой
img_enemy = "ufo.png"  # ворог

lost = 0

class GameSprite(sprite.Sprite):
    # конструктор класу
    def __init__(self, player_image, player_x, player_y, size_x, size_y, player_speed):
        # викликаємо конструктор класу (Sprite):
        super().__init__()
        # кожен спрайт повинен зберігати властивість image - зображення
      
        self.speed = player_speed
        self.image = transform.scale(image.load(player_image), (size_x, size_y))
        # кожен спрайт повинен зберігати властивість rect - прямокутник, в який він вписаний
        self.rect = self.image.get_rect()
        self.rect.x = player_x
        self.rect.y = player_y
    def reset(self):
        window.blit(self.image,(self.rect.x,self.rect.y))

class Player(GameSprite):
    def move(self):
        keys = key.get_pressed()
        if keys [K_LEFT]:
            self.rect.x = self.rect.x - self.speed
        if keys [K_RIGHT]:
            self.rect.x = self.rect.x + self.speed
        if keys [K_UP]:
            self.rect.y = self.rect.y + self.speed 
        if keys [K_DOWN]:
            self.rect.y = self.rect.y - self.speed
    def fire(self):
        bullet = Bullet('bullet.png',self.rect.centerx,self.rect.top,15,20,4)
        bullets.add(bullet)


class Enemy(GameSprite):
    def update(self):
        self.rect.y = self.rect.y + self.speed
        global lost
        if self.rect.y > 500:
            lost = lost + 1
            self.rect.y = 0
            self.rect.x = randint(80,650)
            self.speed = randint(1,2)

class Bullet(GameSprite):
    def update(self):
        self.rect.y = self.rect.y - self.speed
        if self.rect.y < 0:
            self.kill()


hero = Player(img_hero,350,450,50,50,5)

bullets = sprite.Group()
enemyes = sprite.Group()
asteloids = sprite.Group()
try:
    for i in range(1,6):
        enemy = Enemy(img_enemy,randint(80,650),50,50,50,randint(1,4))
        enemyes.add(enemy)
except e:
    print(e)
for i in range(1,6):
    enemy = Enemy('asteroid.png',randint(80,650),50,50,50,randint(1,4))
    asteloids.add(enemy)

game = True
clock = time.Clock()
FPS = 60
score = 0
font.init()
back_image = image.load('galaxy.jpg')
back = transform.scale(back_image,(700,500))

life = 3
finish = False
max_score = 30 
count_monsters = 6

font1 = font.SysFont("Arial",80)
font = font.SysFont("Arial",24)
lose = font1.render('You lose', True, (255,0,0))
win = font1.render('You win', True, (255,0,0))
while game:
    
    for e in event.get():
        if e.type == QUIT:
            game = False
        elif e.type == KEYDOWN:
            if e.key == K_SPACE:
                hero.fire()
    
    


    if not finish:
        window.blit(back,(0,0))
        hero.reset() 
        hero.move()

        enemyes.draw(window)
        enemyes.update()

        bullets.draw(window)
        bullets.update()

        asteloids.draw(window)
        asteloids.update()
        collides = sprite.groupcollide(enemyes, bullets, True, False)
        text2 = font.render('Score:'+str(score),True, (255,255,255))
        window.blit(text2,(20,60))
        text3 = font.render('Need to win:'+str(max_score),True, (255,255,255))
        window.blit(text2,(20,60))
        text1 = font.render('Missed:'+str(lost),True, (255,255,255))
        window.blit(text1,(20,20))


        
        for c in collides:
            score = score + 1
            enemy = Enemy(img_enemy,randint(80,650),50,50,50,randint(1,4))
            enemyes.add(enemy)
        

        if score > max_score:
            finish = True
            window.blit(win,(200,200))

        if sprite.spritecollide(hero, enemyes,False) or sprite.spritecollide(hero, asteloids,False):
            sprite.spritecollide(hero, enemyes,True)
            sprite.spritecollide(hero, asteloids,False)
            life = life - 1

        if life == 0 or lost >=15:
            finish = True
            window.blit(lose,(200,200))

        if life == 3:
            life_color = (0,150,0)
        if life == 2:
            life_color = (150,150,0)
        if life == 1:
            life_color = (150,0,0)

        text_life = font.render(str(life),True,life_color)
        window.blit(text_life,(650,10))
    else:
        finish = False
        score = 0
        lost = 0
        life = 3
        max_score = max_score + 10
        count_monsters = count_monsters + 2
        for e in enemyes:
            e.kill()
        for b in bullets:
            b.kill()
        for a in asteloids:
            a.kill()
        timer.sleep(3)
    
        for i in range(1,count_monsters):
            enemy = Enemy((80,650),50,50,50,img_enemy,(1,4))
            enemyes.add(enemy)

    display.update() 
    clock.tick(FPS)                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 


